from django.shortcuts import redirect, render, reverse
from django.views import generic
from .models import *
from .forms import Registration
    

class Register(generic.CreateView):
    template_name = 'registration/signup.html'
    form_class = Registration
    
    def get_success_url(self):
        return reverse('django:home')

def home(request):
   
    home = Menu.objects.all()
    blog = Blog.objects.all()
    call = Node.objects.all()
    odam = Humans.objects.all()
    turtle = Tiktok.objects.all() 
    our = Our.objects.all()
    contact = Contact.objects.all()
    footer = Footer.objects.all()
    
    context = {
        "home":home,
        "blog":blog,
        "call":call,
        "odam":odam,
        "turtle":turtle,
        "our":our,
        "contact":contact,
        "footer":footer,
    }
    
    return render(request, 'index.html', context)




# def blog(request):
   
#     blog = Blog.objects.all()
#     context = {
#         "blog":blog
#     }
    
