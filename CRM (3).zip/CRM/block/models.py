from django.db import models

class Home(models.Model):
    
    login = models.CharField(max_length=80)
    
    def __str__(self):
        return self.login
    

class Menu(models.Model):
    
    Logo = models.CharField(max_length=30)
    menu1 = models.CharField(max_length=30)
    menu2 = models.CharField(max_length=30)
    menu3 = models.CharField(max_length=30)
    menu4 = models.CharField(max_length=30)
    login = models.CharField(max_length=30)

    
    def __str__(self):
        return self.Logo



class Blog(models.Model):
    
    mavzu = models.CharField(max_length=30)
    matn = models.CharField(max_length=100)
    
    def __str__(self):
        return self.mavzu
    
    
    
    
class Node(models.Model):
    
    mavzu1 = models.CharField(max_length=30)
    matn1 = models.CharField(max_length=100)
    link = models.CharField(max_length=10)
    
    def __str__(self):
        return self.link



class Humans(models.Model):
    
    mavzu2 = models.CharField(max_length=30)
    matn2 = models.CharField(max_length=100)
    link1 = models.CharField(max_length=10)
    
    def __str__(self):
        return self.mavzu2



class Tiktok(models.Model):
    
    mavzu3 = models.CharField(max_length=30)
    matn3 = models.CharField(max_length=100)
    
    def __str__(self):
        return self.mavzu3


class Our(models.Model):
    
    ism = models.CharField(max_length=30)
    kasb = models.CharField(max_length=30)
    
    def __str__(self):
        return self.kasb
    
    
    
    
class Contact(models.Model):
    
    logos = models.CharField(max_length=30)
    logos1 = models.CharField(max_length=30)
    logos2 = models.CharField(max_length=30)
    logos3 = models.CharField(max_length=30)
    logos4 = models.CharField(max_length=30)
    
    def __str__(self):
        return self.logos
    

class Footer(models.Model):
    
    text1 = models.CharField(max_length=300)
    text2 = models.CharField(max_length=30)
    
    def __str__(self):
        return self.text1