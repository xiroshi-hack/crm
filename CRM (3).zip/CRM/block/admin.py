from re import A
from django.contrib import admin
from .models import *

admin.site.register(Home)
admin.site.register(Menu)
admin.site.register(Blog)
admin.site.register(Node)
admin.site.register(Humans)
admin.site.register(Tiktok)
admin.site.register(Our)
admin.site.register(Contact)
admin.site.register(Footer)